@echo off
REM Compile and run the whole test suite (Windows)
if exist out rmdir /s /q out
mkdir out
javac -d out src\*.java test\*.java || exit /b 1
java -cp out EmployeeManagementSystemTest
