# Employee Management System

[![Java CI](https://github.com/YOUR-USERNAME/EmployeeManagementSystem/actions/workflows/ci.yml/badge.svg)](https://github.com/YOUR-USERNAME/EmployeeManagementSystem/actions)

A Java console application for **Organization X** that manages employees, processes their payments and produces payroll reports. It was built for a *Software Testing* assignment: the repository contains the implementation, an automated **black-box** and **white-box** test suite (49 test cases) and the written test case report.

## Features

| Area | What it does |
|------|--------------|
| Employee management | Add and remove employees (ID, name, department, base salary); duplicate IDs and invalid data are rejected; employee count |
| Payment processing | Net pay = base salary pro-rated by hours (max 160 standard hours) + overtime at 1.5x + 10% bonus for *Management* – tax (10% below 2000, 20% from 2000, 30% from 5000) |
| Reporting | Payroll report with each paid employee's net pay, total payroll, average and top earner |

## Project structure

```
EmployeeManagementSystem/
├── src/
│   ├── EmployeeManagementSystem.java      # core logic (records, payments, reports)
│   └── EmsApp.java                        # console menu
├── test/
│   └── EmployeeManagementSystemTest.java  # 27 black-box + 22 white-box test cases
├── docs/
│   └── Test_Case_Report_EMS.docx          # full test case report
├── .github/workflows/ci.yml               # runs the tests on every push
├── run-tests.sh / run-tests.bat           # compile + run the tests
└── README.md
```

## Requirements

Java Development Kit (JDK) 8 or higher (developed and tested with OpenJDK 21). No external libraries.

## Run the application

```bash
mkdir out
javac -d out src/*.java
java -cp out EmsApp
```

## Run the tests

Linux / macOS / Git Bash:

```bash
./run-tests.sh
```

Windows:

```bat
run-tests.bat
```

Each test prints `ID  PASS|FAIL  actual result`, followed by a summary line. The program exits with a non-zero code when any test fails, which is how GitHub Actions detects a failing build.

Expected last line: `SUMMARY  49 passed, 0 failed`

## Test design

* **Black-box (BB-01 to BB-27)** – derived from the 7 functional requirements with equivalence partitioning and boundary value analysis (e.g. gross pay 1999.99 / 2000 / 4999 / 5000, hours 744 / 745, salary -1 / 0).
* **White-box (WB-01 to WB-22)** – derived from the source code to cover every statement, every branch outcome and each condition of the compound decisions.
* Expected values were calculated by hand from the business rules.

### Optional: measure code coverage with JaCoCo

Download the JaCoCo release zip from <https://www.jacoco.org/jacoco/> and extract it, then:

```bash
java -javaagent:jacoco/lib/jacocoagent.jar=destfile=coverage.exec -cp out EmployeeManagementSystemTest
java -jar jacoco/lib/jacococli.jar report coverage.exec \
     --classfiles out --sourcefiles src --html coverage
```

Result obtained for the report: 100% line, 100% branch coverage of `EmployeeManagementSystem`.

## Author

Replace this line with your name and student ID.
