#!/usr/bin/env bash
# Compile and run the whole test suite (Linux / macOS / Git Bash)
set -e
rm -rf out && mkdir out
javac -d out src/*.java test/*.java
java -cp out EmployeeManagementSystemTest
